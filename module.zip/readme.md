Did you need this module?  No.  
Do you want it?  Yes.

What does it do?
It adds a bean texture for Dice-So-Nice

![bean die](https://i.imgur.com/RbYTF0y.png)
